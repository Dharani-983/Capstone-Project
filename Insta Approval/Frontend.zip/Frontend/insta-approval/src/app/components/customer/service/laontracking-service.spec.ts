import { LaontrackingService } from './laontracking-service';

describe('LaontrackingService', () => {
  it('should create an instance', () => {
    const directive = new LaontrackingService();
    expect(directive).toBeTruthy();
  });
});
